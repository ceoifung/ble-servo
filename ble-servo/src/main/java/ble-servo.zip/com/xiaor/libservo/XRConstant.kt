package com.xiaor.libservo

object XRConstant {
    const val REQUEST_CODE = 1000
    const val BLE_OPEN_CODE = 1001
    const val BLE_REQUEST_CODE = 1002
    const val BLE_SCAN_REQUEST = 1003
}