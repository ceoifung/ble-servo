package com.xiaor.libservo

enum class BleStatus {
    CONNECTED, DISCONNECTED, CONNECTING, FAILURE
}